"""
IBM Data Visualization Final Assignment — Part 2
Automobile Sales Statistics Dashboard (XYZAutomotives)

Run:
    pip install pandas plotly dash
    python Part2_Automobile_Sales_Dashboard.py

The script downloads the official course CSV if it is not in the current directory.
"""
from pathlib import Path
from urllib.request import urlretrieve

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output

DATA_URL = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101ENSkillsNetwork/Data%20Files/historical_automobile_sales.csv"
DATA_FILE = Path("historical_automobile_sales.csv")

if not DATA_FILE.exists():
    try:
        urlretrieve(DATA_URL, DATA_FILE)
    except Exception as exc:
        raise FileNotFoundError(
            "Could not download the dataset. Place historical_automobile_sales.csv "
            "in the same folder as this script."
        ) from exc

data = pd.read_csv(DATA_FILE)
if "Unemployment_Rate" not in data.columns and "unemployment_rate" in data.columns:
    data.rename(columns={"unemployment_rate": "Unemployment_Rate"}, inplace=True)

required = ["Year", "Recession", "Automobile_Sales", "Vehicle_Type",
            "Advertising_Expenditure", "GDP", "Unemployment_Rate"]
missing = [column for column in required if column not in data.columns]
if missing:
    raise ValueError(f"Dataset is missing required columns: {missing}")

data["Year"] = pd.to_numeric(data["Year"], errors="coerce")
data["Recession"] = pd.to_numeric(data["Recession"], errors="coerce").fillna(0).astype(int)
year_options = [{"label": str(int(y)), "value": int(y)}
                for y in sorted(data["Year"].dropna().unique())]

app = Dash(__name__)
app.title = "Automobile Sales Statistics Dashboard"

app.layout = html.Div(
    className="container",
    children=[
        html.H1("Automobile Sales Statistics Dashboard",
                style={"textAlign": "center", "marginBottom": "24px"}),
        html.Div([
            html.Label("Select Report Type:", style={"fontWeight": "bold"}),
            dcc.Dropdown(
                id="report-type",
                options=[
                    {"label": "Yearly Statistics", "value": "yearly"},
                    {"label": "Recession Period Statistics", "value": "recession"},
                ],
                value="yearly",
                clearable=False,
            ),
        ], style={"width": "48%", "display": "inline-block", "padding": "8px"}),
        html.Div([
            html.Label("Select Year:", style={"fontWeight": "bold"}),
            dcc.Dropdown(
                id="year-dropdown",
                options=year_options,
                value=int(data["Year"].dropna().max()),
                clearable=False,
            ),
        ], style={"width": "48%", "display": "inline-block", "padding": "8px"}),
        html.Div(id="output-container", className="chart-grid"),
    ],
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "1200px",
           "margin": "0 auto", "padding": "20px"},
)

@app.callback(
    Output("output-container", "children"),
    Input("report-type", "value"),
    Input("year-dropdown", "value"),
)
def update_dashboard(report_type, selected_year):
    charts = []
    if report_type == "recession":
        recession_data = data[data["Recession"] == 1]
        if recession_data.empty:
            return html.P("No recession-period records are available in the dataset.")

        yearly = recession_data.groupby("Year", as_index=False)["Automobile_Sales"].mean()
        fig1 = px.line(yearly, x="Year", y="Automobile_Sales", markers=True,
                       title="Average Automobile Sales During Recession Periods")

        by_type = recession_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].mean()
        fig2 = px.bar(by_type, x="Vehicle_Type", y="Automobile_Sales",
                      title="Average Sales by Vehicle Type During Recessions")

        ad = recession_data.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"].sum()
        fig3 = px.pie(ad, names="Vehicle_Type", values="Advertising_Expenditure",
                      title="Advertising Expenditure by Vehicle Type During Recessions")

        gdp = recession_data.groupby("Year", as_index=False)["GDP"].mean()
        fig4 = px.line(gdp, x="Year", y="GDP", markers=True,
                       title="Average GDP During Recession Periods")

        for fig in [fig1, fig2, fig3, fig4]:
            fig.update_layout(margin=dict(l=30, r=30, t=60, b=40))
            charts.append(dcc.Graph(figure=fig))
    else:
        yearly_data = data[data["Year"] == selected_year]
        if yearly_data.empty:
            return html.P("No records are available for the selected year.")

        monthly = yearly_data.copy()
        if "Month" in monthly.columns:
            month_order = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            monthly["Month"] = pd.Categorical(monthly["Month"], categories=month_order, ordered=True)
            monthly = monthly.sort_values("Month")
            x_column = "Month"
        else:
            monthly["Date"] = pd.to_datetime(monthly["Date"], errors="coerce")
            monthly = monthly.sort_values("Date")
            x_column = "Date"

        fig1 = px.line(monthly, x=x_column, y="Automobile_Sales", markers=True,
                       title=f"Monthly Automobile Sales — {selected_year}")
        fig2 = px.line(monthly, x=x_column, y="Advertising_Expenditure", markers=True,
                       title=f"Monthly Advertising Expenditure — {selected_year}")
        by_type = yearly_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].sum()
        fig3 = px.bar(by_type, x="Vehicle_Type", y="Automobile_Sales",
                      title=f"Automobile Sales by Vehicle Type — {selected_year}")
        fig4 = px.pie(by_type, names="Vehicle_Type", values="Automobile_Sales",
                      title=f"Sales Share by Vehicle Type — {selected_year}")

        for fig in [fig1, fig2, fig3, fig4]:
            fig.update_layout(margin=dict(l=30, r=30, t=60, b=40))
            charts.append(dcc.Graph(figure=fig))

    return html.Div(charts, style={
        "display": "grid",
        "gridTemplateColumns": "repeat(auto-fit, minmax(420px, 1fr))",
        "gap": "18px",
    })

if __name__ == "__main__":
    app.run(debug=True)
