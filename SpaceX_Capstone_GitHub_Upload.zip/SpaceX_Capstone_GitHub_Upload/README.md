# IBM Applied Data Science Capstone — SpaceX Falcon 9 Landing Prediction

This repository folder contains the current capstone presentation draft and additional IBM Data Science coursework files prepared during the project.

## Important before submission

The PDF/PowerPoint currently includes some illustrative charts and reference model scores. Verify and replace them with results from your own executed capstone notebooks before treating the presentation as final.

To complete the repository for the course rubric, upload the actual completed SpaceX capstone notebooks and Python files from your IBM Skills Network workspace, including (as applicable):
- Data collection using the SpaceX API
- Web scraping and data wrangling
- Exploratory data analysis with visualizations
- EDA using SQL
- Folium interactive map
- Plotly Dash dashboard (`.py` file)
- Predictive analysis / classification
- Any required supporting datasets and a README describing how to run the work

Do not upload API tokens, passwords, or other private credentials.
