IBM Data Visualization Final Assignment — files prepared

1) Q1: Upload Part1_Automobile_Sales_Visualizations.ipynb
   - Open in Jupyter Notebook, JupyterLab, Google Colab, or VS Code.
   - Run all cells from top to bottom before uploading.
   - The notebook attempts to download the IBM course dataset automatically.
   - If automatic download fails, download historical_automobile_sales.csv from the course materials and put it beside the notebook.

2) Q4: Upload Part2_Automobile_Sales_Dashboard.py
   - Install dependencies: pip install pandas plotly dash
   - Place historical_automobile_sales.csv in the same folder if automatic download fails.
   - Run: python Part2_Automobile_Sales_Dashboard.py
   - Open the local URL printed by Dash to view the interactive dashboard.

Important:
- Q2, Q3, Q5, Q6, Q7, Q8, and Q9 are separate quiz/image questions; these two files do not answer those.
- Review the notebook after running it and ensure the charts display properly before submission.
- These files are built to match the criteria visible in your screenshots. If your course's starter notebook has different exact cell requirements, compare before submitting.
